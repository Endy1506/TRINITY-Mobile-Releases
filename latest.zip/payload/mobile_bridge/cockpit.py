"""TRINITY Mobile Cockpit v0.10.3.

Loopback-only control panel for finite, approval-bound v0.8 discovery campaigns.
Only finite allowlisted parameters, no shell, network calls, or autoapproval.
A browser login token + independent CSRF nonce + same-origin checks guard POSTs.
Worker threads exist only while this Termux process runs. Interrupted steps HOLD.
"""
import argparse
import fcntl
import hashlib
import hmac
import html
import json
import os
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlsplit

from . import discovery_manager as discovery
from .bridge import digest, load
from .control import snapshot
from . import updater
from . import widget_status

PAGE_LIMIT = 32768
DEFAULT_COUNT = 6
DEFAULT_BUDGET = 100
DEFAULT_TRIALS = 2
MAX_UI_EVALUATIONS = 240_000
ALLOWED_COUNTS = {2,3,4,6,8,12}
ALLOWED_BUDGETS = {50,100,200}
ALLOWED_TRIALS = {1,2,4}


def escape(x):
    return html.escape(str(x), quote=True)


def _qs_token(token):
    return '?'+urlencode({'token': token})


def _form(action, fields, token, csrf, button, danger=False):
    # All submitted values are html-escaped; no JavaScript, no arbitrary path.
    hidden = ''.join(f'<input type="hidden" name="{escape(k)}" value="{escape(v)}">' for k,v in fields.items())
    hidden += f'<input type="hidden" name="csrf" value="{escape(csrf)}">'
    return (f'<form method="post" action="{escape(action)}{escape(_qs_token(token))}">'
            + hidden + f'<button type="submit" class="{"danger" if danger else "primary"}">{escape(button)}</button></form>')


CSS = '''
:root{color-scheme:dark}*{box-sizing:border-box}
body{font:16px/1.5 system-ui,-apple-system,sans-serif;color:#e5eaf2;background:#0c1423;max-width:850px;margin:auto;padding:17px}
header{display:flex;gap:14px;align-items:center;justify-content:space-between;flex-wrap:wrap}
h1{font-size:1.45rem;margin:0}h2{font-size:1.05rem;margin:0 0 8px}
main{display:grid;gap:13px;margin-top:16px}.panel{border:1px solid #3b4b63;border-radius:14px;background:#19283c;padding:15px}
.muted{color:#a9bbcf;font-size:.87rem}.good{color:#86f4b9}.warn{color:#ffcf8e}.bad{color:#ff9da8}
label{display:block;margin:9px 0 3px}input,select,button,a.link{font:inherit;border-radius:9px;padding:10px}
select,input{width:100%;color:#f6f8fb;background:#0d1828;border:1px solid #64748b}
button,a.link{display:inline-block;color:white;background:#345e91;border:0;text-decoration:none;cursor:pointer}
button.primary{background:#087e60}button.danger{background:#983a4e}a.link{background:#314155}
button:focus,input:focus,select:focus{outline:2px solid #a8d2fd}
.actions{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0 0}.mono{font:12px/1.6 ui-monospace,monospace;overflow-wrap:anywhere}
.counter{font-size:1.6rem;font-weight:750}.line{border-top:1px solid #41516b;padding:12px 0}
summary{cursor:pointer}.meter{background:#122032;border-radius:9px;overflow:hidden;height:12px;margin-top:7px}
.bar{background:#29a67b;height:100%}form{margin:0}p{margin:6px 0 12px}
'''


def _layout(title, body, token, refresh=False):
    head = ('<!doctype html><html lang="ro"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<meta name="referrer" content="no-referrer">'
            + (f'<meta http-equiv="refresh" content="12;url=/{escape(_qs_token(token))}">' if refresh else '')
            + f'<title>{escape(title)} · TRINITY</title><style>{CSS}</style></head><body>')
    return (head+f'<header><h1>TRINITY Mobile Bridge</h1><a class="link" href="/{escape(_qs_token(token))}">Panou</a></header>'
            +f'<main>{body}</main><p class="muted">Local pe telefon · fără ESPRIMO · operații limitate. '
            'Nu distribui adresa cu token. Android poate suspenda Termux.</p></body></html>')


class Coordinator:
    """Serial campaign dispatcher, with kernel-released cross-process lock.

    Never resumes a HOLD state. Lock FD held until background run finishes.
    """
    def __init__(self, base):
        self.base = Path(base)
        self.root = self.base/'mobile-discovery'
        self.guard = threading.Lock()
        self.current = None
        self.running = False
        self.last_error = None
        self.last_identifier = None
        self.maintenance = False

    def active(self):
        with self.guard:
            return {'running': self.running, 'id':self.current, 'last_error':self.last_error, 'maintenance':self.maintenance}

    def dispatch(self, ident):
        path = discovery.directory(self.root, ident)
        manifest = discovery.validate_plan(load(path/'plan.json'))
        if manifest['id'] != ident:
            raise ValueError('campaign identity mismatch')
        discovery.inspect_approval(path,manifest)
        state = discovery.verify_state(path,manifest)
        if state['status'] not in ('NEW','READY'):
            raise ValueError('campaign already DONE/HOLD')
        with self.guard:
            if self.running or self.maintenance:
                raise ValueError('worker busy or update maintenance')
            self.root.mkdir(parents=True,exist_ok=True)
            lockpath = self.root/'.cockpit-executor.lock'
            if lockpath.is_symlink():
                raise ValueError('unsafe supervisor lock path')
            fd=os.open(str(lockpath),os.O_CREAT|os.O_RDWR,0o600)
            try:
                fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
                # Recheck after cross-process acquisition.
                discovery.inspect_approval(path,manifest)
                state = discovery.verify_state(path,manifest)
                if state['status'] not in ('NEW','READY'):
                    raise ValueError('campaign not ready at dispatch')
                self.running=True
                self.current=ident
                self.last_error=None
                self.last_identifier=ident
                task=threading.Thread(target=self._run,args=(ident,fd),daemon=True,name='trinity-bounded-campaign')
                task.start()
                return {'status':'STARTED','campaign':ident}
            except BaseException:
                self.running=False
                self.current=None
                fcntl.flock(fd,fcntl.LOCK_UN)
                os.close(fd)
                raise

    def _run(self, ident, lockfd):
        try:
            # Each step re-checks the approved plan, source hashes and revocation.
            # A crash during a step leaves a durable HOLD + claim as evidence.
            while True:
                answer = discovery.step(self.root,ident)
                if answer['status'] != 'READY':
                    if answer['status'] != 'DONE':
                        with self.guard:
                            self.last_error='Step ended without PASS: '+str(answer['status'])[:70]
                    break
        except Exception as exc:
            with self.guard:
                self.last_error = str(exc)[:150]
        finally:
            fcntl.flock(lockfd,fcntl.LOCK_UN)
            os.close(lockfd)
            with self.guard:
                self.running = False
                self.current = None


def _render_overview(base, token, csrf, coord):
    snap=snapshot(base)
    active=coord.active()
    verified=sum(1 for x in snap['jobs']+snap['discovery_v08'] if x.get('verified') and x.get('status') in ('PASS','DONE'))
    holds=sum(1 for x in snap['jobs']+snap['discovery_v08'] if x.get('status')=='HOLD')+len(snap['warnings'])
    items=['<section class="panel"><h2>Laborator mobil</h2>'
           +f'<div class="counter">{verified} rezultate verificate · {holds} HOLD</div>'
           +'<p class="muted">O aprobare pentru o campanie limitată. Experimentele sunt executate în Termux.</p>'
           +f'<a class="link" href="/new{escape(_qs_token(token))}">+ Planifică o campanie</a>'
           +f' <a class="link" href="/updates{escape(_qs_token(token))}">Actualizări verificate</a>'
           +f' <a class="link" href="/widget-setup{escape(_qs_token(token))}">Mini Widget 2×2</a></section>']
    if active['running']:
        items.append(f'<section class="panel"><h2>Worker ACTIV</h2><p class="mono">{escape(active["id"])}</p>'
                     '<p class="muted">Avansul se actualizează automat.</p></section>')
    if active['last_error']:
        items.append(f'<section class="panel"><h2 class="bad">Ultima eroare · HOLD</h2><p>{escape(active["last_error"])}</p></section>')
    if snap['warnings']:
        items.append('<section class="panel"><h2 class="bad">Avertizări audit</h2>'
                     +''.join('<p>'+escape(x)+'</p>' for x in snap['warnings'])+'</section>')
    rows=snap['discovery_v08']
    if rows:
        body=['<section class="panel"><h2>Campanii Discovery</h2>']
        for row in reversed(rows):
            ident=row['id']
            status=row.get('status','HOLD')
            # Discovery intentionally writes fail-closed HOLD before each step.
            # While the *same* coordinator is actively executing this campaign,
            # that state is provisional, not evidence of completed failure.
            in_flight = (active['running'] and active['id']==ident
                         and status=='HOLD' and row.get('verified') is True)
            display_status = 'EXECUTING · protected HOLD' if in_flight else status
            completed=row.get('completed') or 0
            total=row.get('total') or 0
            pct=round(100*completed/total) if total else 0
            color='good' if status=='DONE' and row.get('verified') else ('bad' if status=='HOLD' else 'warn')
            body.append(f'<div class="line"><div class="mono">{escape(ident)}</div>'
                        f'<strong class="{color}">{escape(display_status)}</strong> · '
                        f'{escape(completed)}/{escape(total)} pași'
                        f'<div class="meter"><div class="bar" style="width:{pct}%"></div></div>'
                        f'<div class="actions"><a class="link" href="/review/{escape(ident)}{escape(_qs_token(token))}">Detalii / acțiuni</a></div></div>')
        body.append('</section>')
        items.append(''.join(body))
    else:
        items.append('<section class="panel">Nu există încă nicio campanie locală.</section>')
    items.append('<section class="panel"><details><summary>Joburi individuale și verificări v0.9</summary>'
                 +'<p class="muted">Nu sunt reexecutate automat.</p>'
                 +''.join(f'<p class="mono">{escape(r["id"])} · {escape(r["status"])}</p>' for r in snap['jobs'])
                 +'</details></section>')
    return _layout('Monitor', ''.join(items), token, refresh=True)


def _widget_setup_page(base,token,csrf):
    state='Împerecheat' if (Path(base)/'.trinity-widget-status-key').exists() else 'Neîmperecheat'
    body='<section class="panel"><h2>TRINITY Mini Cockpit 2×2</h2>'
    body+='<p>Stare: <strong>'+escape(state)+'</strong></p>'
    body+='<p class="muted">Widget Android nativ în dezvoltare. Cheia lui oferă numai citire de stare verificată, nu execuție, aprobări sau actualizări.</p>'
    if state=='Neîmperecheat':
        body+=_form('/action/widget-enroll',{},token,csrf,'Generează cheia de împerechere (o singură dată)')
    else:
        body+='<p class="warn">Cheia există deja. Nu este reafișată; nu există rotație automată.</p>'
    body+='</section>'
    return _layout('Mini Widget',body,token)


def _new_page(token,csrf):
    form=(f'<form method="post" action="/action/plan{escape(_qs_token(token))}">'
          +f'<input type="hidden" name="csrf" value="{escape(csrf)}">'
          +'<label>Experimente (aprobi maximum)</label><select name="count">'
          +''.join(f'<option value="{x}" {"selected" if x==6 else ""}>{x}</option>' for x in sorted(ALLOWED_COUNTS))+'</select>'
          +'<label>Buget evaluări / problemă</label><select name="budget">'
          +''.join(f'<option value="{x}" {"selected" if x==100 else ""}>{x}</option>' for x in sorted(ALLOWED_BUDGETS))+'</select>'
          +'<label>Rulări comparative</label><select name="trials">'
          +''.join(f'<option value="{x}" {"selected" if x==2 else ""}>{x}</option>' for x in sorted(ALLOWED_TRIALS))+'</select>'
          +'<label>Seed determinist</label><input inputmode="numeric" type="number" min="0" max="2147483600" name="seed" value="42" required>'
          +'<button type="submit" class="primary" style="margin-top:15px">Creează planul (nu execută)</button></form>')
    return _layout('Planifică', '<section class="panel"><h2>Plan nou, cu limite ferme</h2>'
                   '<p class="muted">Vei verifica digestul și bugetul exact înainte de aprobare. '
                   'Nu se acceptă comenzi shell sau cod generat.</p>'+form+'</section>',token)


def _review_page(base, token,csrf,ident,coord):
    root=Path(base)/'mobile-discovery'
    p=discovery.directory(root,ident)
    plan=discovery.validate_plan(load(p/'plan.json'),allow_expired=True)
    if plan['id']!=ident: raise ValueError('identity mismatch')
    report=discovery.status(root,ident)
    status=report['status']
    # A step's durable on-disk state is deliberately HOLD until the step
    # commits. Only annotate it as running while the in-process worker is
    # alive for this exact campaign and evidence validation is coherent.
    active=coord.active()
    in_flight=(status=='HOLD' and report.get('evidence_verified') is True
               and active['running'] and active['id']==ident)
    display_status='ÎN EXECUȚIE (HOLD protectiv temporar)' if in_flight else status
    expires=plan['expires']-int(time.time())
    expired=expires<=0
    approved=report['approved']
    body=['<section class="panel"><h2>Contractul campaniei</h2>'
          f'<p class="mono">{escape(ident)}</p>'
          f'<p>Stare: <strong>{escape(display_status)}</strong> · aprobată: {"DA" if approved else "NU"}</p>'
          f'<p>{plan["count"]} experimente · budget {plan["budget"]} · {plan["trials"]} trials'
          f' · maxim {plan["eval_cap"]:,} evaluări · seed {plan["seed"]}</p>'
          f'<p>Pilot candidați: {escape(", ".join(map(str,plan["pilots"])))}</p>'
          f'<p class="{"bad" if expired else "muted"}">Valabilitate: {"EXPIRATĂ" if expired else f"{expires} secunde rămase"}</p>'
          f'<p>Digest aprobare SHA-256:</p><p class="mono">{escape(digest(plan))}</p>'
          '<p class="muted">Optimizare pe date de antrenare, benchmark demonstrativ. Nu revendicăm noutate științifică.</p>']
    if not expired and status in ('NEW','READY') and not active['running']:
        action='/action/start' if approved else '/action/approve-start'
        title='Pornește restul pașilor aprobați' if approved else 'Aprobă acest plan exact și pornește'
        body.append(_form(action,{'id':ident,'digest':digest(plan)},token,csrf,title))
    if not expired and status in ('NEW','READY') and not (p/'revoked').exists():
        body.append('<div class="actions">'+_form('/action/revoke',{'id':ident,'digest':digest(plan)},token,csrf,'Revocă / oprește',True)+'</div>')
    if in_flight:
        body.append('<p class="warn">Experiment în curs. Motorul păstrează intenționat '
                    'HOLD pe disc până la confirmarea rezultatului; așteaptă '
                    'actualizarea automată. Nu închide Termux în acest moment.</p>')
    elif status=='HOLD':
        body.append('<p class="bad">Campania este în HOLD. Nu va fi reluată automat. '
                    'Inspectează starea și dovezile înaintea unui plan nou.</p>')
        if report.get('reason'):
            body.append(f'<p class="bad">Diagnostic audit: {escape(report["reason"])}</p>')
        elif active['last_error'] and coord.last_identifier == ident:
            body.append(f'<p class="bad">Diagnostic worker: {escape(active["last_error"])}</p>')
        else:
            body.append('<p class="muted">Execuția poate fi întreruptă sau neconfirmată. '
                        'Păstrează dovezile; nu șterge claim-urile și nu forța reluarea.</p>')
    body.append('</section>')
    return _layout('Aprobare', ''.join(body),token, refresh=bool(active['running']))


def _updates_page(base, token, csrf,coord, supervised=True):
    """Never exposes a network URL, key or a write-capable operation implicitly."""
    info=updater.status(base)
    body=['<section class="panel"><h2>Actualizări TRINITY — autorizare explicită</h2>',
          f'<p>Stare: <strong>{escape(info["status"])}</strong></p>',
          f'<p>Versiune activată: {escape(info.get("current",{}).get("version","necunoscut"))}</p>']
    if info.get('last_check'):
        check=info['last_check']
        body.append('<p class="muted">Ultima verificare: '+escape(check.get('status','necunoscut'))+
                    ' · '+escape(check.get('version',''))+'</p>')
    if info.get('last_failed'):
        body.append('<p class="bad">Ultimul update a fost recuperat prin rollback: '+escape(info['last_failed'].get('reason',''))+'</p>')
    if info.get('publisher_fingerprint_sha256'):
        body.append('<p class="muted">Amprentă cheie editor (SHA-256):</p>'
                    f'<p class="mono">{escape(info["publisher_fingerprint_sha256"])}</p>')
    if info['status']=='NO_TRUST_KEY' or (info['status']=='READY' and not info.get('staged') and not (Path(base)/'.trinity-updates'/'channel.json').exists()):
        body.append('<p class="warn">Configurare unică necesară: cheia publică a editorului, '
                    'amprenta verificată independent și adresa HTTPS fixă. '
                    'Cheia privată NU se introduce aici.</p>')
        body.append('<form method="post" action="/action/update-enroll'+escape(_qs_token(token))+'">'
                    '<input type="hidden" name="csrf" value="'+escape(csrf)+'">'
                    '<label>Cheie PUBLICĂ Ed25519 (PEM)</label>'
                    '<textarea name="public_pem" rows="5" required '
                    'style="width:100%;background:#0d1828;color:white;border:1px solid #64748b;'
                    'border-radius:9px;padding:10px"></textarea>'
                    '<label>Amprentă SHA-256 dintr-o sursă independentă (64 caractere)</label>'
                    '<input name="fingerprint" maxlength="64" required>'
                    '<label>URL HTTPS fix către pachetul semnat</label>'
                    '<input name="url" maxlength="1024" required placeholder="https://example.org/trinity/latest.zip">'
                    '<p class="muted">Fără configurație oficială verificată, păstrăm NO_TRUST_KEY. '
                    'Nu folosi o cheie necunoscută furnizată de un site arbitrar.</p>'
                    '<button type="submit" class="primary">Fixez editorul și canalul (o singură dată)</button></form>')
    elif info['status']=='READY':
        channel=(Path(base)/'.trinity-updates'/'channel.json').is_file()
        if not info.get('staged') and channel and not info.get('approved'):
            body.append(_form('/action/update-check',{},token,csrf,'Verifică actualizări semnate'))
        elif not channel:
            body.append('<p class="warn">Canalul oficial nu este configurat. '
                        'Nu vom contacta un server ales arbitrar.</p>')
        if info.get('staged'):
            staged=info['staged']
            body.append(f'<p>Versiune disponibilă: <strong>{escape(staged["version"])}</strong> '
                        f'· secvența {escape(staged["sequence"])}</p>'
                        f'<p class="muted">Digest manifest semnat SHA-256:</p>'
                        f'<p class="mono">{escape(staged["manifest_sha256"])}</p>')
            if staged.get('files'):
                body.append('<p class="muted">Fișiere UI permise de manifestul semnat:</p>')
                for name,hash_value in sorted(staged['files'].items()):
                    body.append(f'<p class="mono">{escape(name)} · {escape(hash_value)}</p>')
            if not info['approved']:
                body.append(_form('/action/update-cancel',{'digest':staged['manifest_sha256']},
                                  token,csrf,'Renunță la această actualizare',danger=True))
            if info['approved']:
                body.append('<p class="warn">Actualizare deja aprobată. '
                            'Se va aplica la următoarea pornire sigură.</p>')
                if not coord.active()['running'] and supervised:
                    body.append(_form('/action/update-restart',{},token,csrf,'Repornește controlat pentru actualizare'))
            elif not coord.active()['running'] and supervised:
                body.append('<p>Aprobarea autorizează exclusiv fișiere UI declarate în manifest. '
                            'Motorul Discovery și cheile de încredere nu pot fi schimbate prin acest canal.</p>')
                body.append(_form('/action/update-approve-restart',{'digest':staged['manifest_sha256']},
                                  token,csrf,'Aprob exact această actualizare și repornesc'))
            else:
                body.append('<p class="warn">Worker activ: instalarea este blocată până la finalizarea campaniei.</p>')
        if not supervised:
            body.append('<p class="warn">Instanță pornită fără lansatorul verificat. '
                        'Pentru activare, deschide TRINITY din widget după oprirea controlată '
                        'a acestei instanțe.</p>')
    elif info['status']=='HOLD_RECOVERY':
        body.append('<p class="bad">Aplicare întreruptă — recuperarea va fi încercată '
                    'la pornirea controlată. Nu șterge fișiere.</p>')
    else:
        body.append('<p class="bad">Diagnostic actualizări în HOLD: '+escape(info.get('reason',''))+'</p>')
    body.append('<p class="muted">Nu există actualizare automată de cod. Fără editor '
                'semnatar configurat, TRINITY continuă să funcționeze offline cu versiunea existentă.</p></section>')
    return _layout('Actualizări', ''.join(body),token)


def _create_plan(base, fields):
    if set(fields)!= {'csrf','count','budget','trials','seed'} or any(len(v)!=1 for v in fields.values()):
        raise ValueError('invalid plan form')
    def number(k):
        value=fields[k][0]
        if not value.isdecimal() or len(value)>11: raise ValueError('invalid plan number')
        return int(value)
    count,budget,trials,seed=(number(k) for k in ('count','budget','trials','seed'))
    if count not in ALLOWED_COUNTS or budget not in ALLOWED_BUDGETS or trials not in ALLOWED_TRIALS:
        raise ValueError('unsupported campaign settings')
    if count*3*trials*4*budget>MAX_UI_EVALUATIONS:
        raise ValueError('evaluation budget exceeded')
    pilots=(10,12) if budget==50 else (10,15,20)
    return discovery.plan(Path(base)/'mobile-discovery',count,budget,trials,seed,pilots,ttl=6*3600)


def _query_token(query,token):
    values=parse_qs(query,keep_blank_values=True).get('token',[])
    return len(values)==1 and hmac.compare_digest(values[0],token)


def _origin_class(origin, port):
    """Small, non-secret diagnosis. Never echo potentially malicious header values."""
    if origin is None:
        return 'absent'
    if origin == 'null':
        return 'opaque-null'
    if not isinstance(origin, str):
        return 'malformed'
    try:
        parts=urlsplit(origin)
        if (parts.scheme.lower() == 'http' and parts.hostname == '127.0.0.1'
                and parts.port == port and not parts.username and not parts.password
                and parts.path in ('','/') and not parts.query and not parts.fragment):
            return 'exact-loopback'
        if parts.hostname in ('127.0.0.1','localhost','::1'):
            return 'different-loopback-origin'
        return 'other-origin'
    except ValueError:
        return 'malformed'


def _origin_allowed(origin, site, mode, dest, port):
    """Accept an opaque Origin ONLY with browser-attested same-origin form metadata.

    HMAC-bound bearer token and an independent CSRF nonce are checked elsewhere.
    Origin:null with cross-site/same-site/missing metadata must stay blocked.
    """
    cls=_origin_class(origin,port)
    if cls in ('absent','exact-loopback'):
        return True
    return (cls=='opaque-null' and site=='same-origin'
            and mode=='navigate' and dest=='document')



# Read-only, unauthenticated challenge response: exposes no browser bearer secret.
# Used by Termux:Widget to identify a running TRINITY without sending credentials
# to arbitrary processes that might be listening on the same loopback port.
INSTANCE_SCHEMA = 'trinity.mobile.cockpit.instance.v1'
INSTANCE_ROUTE = '/_trinity/instance'


def instance_proof(token, csrf, base, port, nonce):
    if (type(nonce) is not str or len(nonce) != 64 or
            any(c not in '0123456789abcdef' for c in nonce)):
        raise ValueError('invalid instance challenge')
    if type(port) is not int or not 1024 <= port <= 65535:
        raise ValueError('invalid instance port')
    material = ('TRINITY_INSTANCE_V1\0' + str(Path(base).resolve()) +
                '\0' + str(port) + '\0' + nonce).encode('utf-8')
    key = (token + '\0' + csrf).encode('utf-8')
    return hmac.new(key, material, hashlib.sha256).hexdigest()


def handler_factory(base, token,csrf,coordinator, port, supervised=True):
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.0'
        def log_message(self,*args):
            pass  # URLs and tokens must not leak to logs.

        def headers_safe(self, code, length=0, content='text/html; charset=utf-8', extra=None):
            self.send_response(code)
            self.send_header('Content-Type',content)
            self.send_header('Content-Length',str(length))
            for k,v in (('Cache-Control','no-store'),('Referrer-Policy','no-referrer'),
                        ('X-Content-Type-Options','nosniff'),('X-Frame-Options','DENY'),
                        ('Cross-Origin-Resource-Policy','same-origin'),
                        ('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")):
                self.send_header(k,v)
            if getattr(self,'_set_cookie',False):
                self.send_header('Set-Cookie',f'trinity_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=15552000')
            if extra:
                for k,v in extra.items():self.send_header(k,v)
            self.end_headers()

        def _host_ok(self):
            return self.headers.get('Host','') in (f'127.0.0.1:{port}', '127.0.0.1')
        def _auth(self):
            if not self._host_ok():return False
            query=_query_token(urlsplit(self.path).query,token)
            cookie=self.headers.get('Cookie','')
            cookie_good=any(hmac.compare_digest(x.strip(), 'trinity_session='+token)
                            for x in cookie.split(';'))
            self._set_cookie=query and not cookie_good
            return query or cookie_good
        def _response(self,code,message):
            data=message.encode('utf-8')
            self.headers_safe(code,len(data))
            self.wfile.write(data)
        def _deny(self, reason, detail=None):
            # A refusal reason for Android browser compatibility diagnostics.
            # Never echo the URL, bearer token, CSRF secret, or supplied headers.
            known = {
                'AUTH': 'Tokenul sau adresa locală nu sunt valide. Redeschide adresa completă din Termux.',
                'ORIGIN': 'Browserul a trimis un Origin diferit de cel local autorizat.',
                'FETCH_SITE': 'Contextul cererii browserului nu este permis pentru o operație de scriere.',
                'CSRF': 'Lipsește sau nu corespunde confirmarea formularului. Reîncarcă pagina din Panou.',
            }
            reason = reason if reason in known else 'AUTH'
            page = ('<!doctype html><html lang="ro"><meta charset="utf-8">'
                    '<meta name="viewport" content="width=device-width,initial-scale=1">'
                    '<title>TRINITY · Cerere respinsă</title>'
                    '<body style="font:18px system-ui;padding:25px;background:#0c1423;color:#fff">'
                    f'<h1>403 · {reason}</h1><p>{known[reason]}</p>'
                    +(f'<p>Diagnostic sigur: {escape(detail)}</p>' if detail else '')
                    +'<p>Nicio acțiune nu a fost autorizată. Comunică doar codul de mai sus, '
                    'nu adresa completă sau tokenul.</p></body></html>')
            return self._response(403,page)
        def _go(self,path):
            self.headers_safe(303,0,extra={'Location':path+_qs_token(token)})
        def do_GET(self):
            url=urlsplit(self.path)
            # Zero-authority challenge: no token/cookie is required or returned.
            # Wrong paths, hostnames, or malformed nonces are rejected.
            if url.path == INSTANCE_ROUTE:
                if not self._host_ok():return self.headers_safe(403)
                params=parse_qs(url.query,keep_blank_values=True)
                if set(params) != {'nonce'} or len(params['nonce'])!=1:
                    return self.headers_safe(400)
                nonce=params['nonce'][0]
                try:proof=instance_proof(token,csrf,base,port,nonce)
                except ValueError:return self.headers_safe(400)
                payload=json.dumps({'schema':INSTANCE_SCHEMA,'nonce':nonce,
                                    'proof':proof},sort_keys=True).encode('utf-8')
                self.headers_safe(200,len(payload),'application/json; charset=utf-8')
                return self.wfile.write(payload)
            if url.path == widget_status.ROUTE:
                if not self._host_ok():return self.headers_safe(403)
                params=parse_qs(url.query,keep_blank_values=True)
                if set(params)!={'nonce'} or len(params['nonce'])!=1:
                    return self.headers_safe(400)
                try:
                    payload,mac=widget_status.authenticated_status(
                        base,params['nonce'][0],self.headers.get('X-Trinity-Widget-Proof'),
                        coordinator.active())
                except (ValueError,OSError,TypeError):return self.headers_safe(403)
                self.headers_safe(200,len(payload),'application/json; charset=utf-8',
                                  extra={'X-Trinity-Widget-MAC':mac})
                return self.wfile.write(payload)
            if not self._auth():return self.headers_safe(403)
            route=url.path
            try:
                if route=='/': page=_render_overview(base,token,csrf,coordinator)
                elif route=='/new': page=_new_page(token,csrf)
                elif route=='/updates': page=_updates_page(base,token,csrf,coordinator,supervised)
                elif route=='/widget-setup': page=_widget_setup_page(base,token,csrf)
                elif route.startswith('/review/'):
                    ident=route.removeprefix('/review/')
                    page=_review_page(base,token,csrf,ident,coordinator)
                elif route=='/api/status':
                    data=json.dumps({'snapshot':snapshot(base),'worker':coordinator.active()},sort_keys=True).encode()
                    self.headers_safe(200,len(data),'application/json; charset=utf-8')
                    return self.wfile.write(data)
                else:return self.headers_safe(404)
            except (ValueError,KeyError,TypeError,OverflowError,OSError) as exc:
                return self._response(409,_layout('HOLD',f'<section class="panel"><h2 class="bad">HOLD</h2><p>{escape(str(exc))}</p></section>',token))
            data=page.encode('utf-8')
            self.headers_safe(200,len(data))
            self.wfile.write(data)
        def do_POST(self):
            if not self._auth():return self._deny('AUTH')
            origin=self.headers.get('Origin')
            site=self.headers.get('Sec-Fetch-Site')
            mode=self.headers.get('Sec-Fetch-Mode')
            dest=self.headers.get('Sec-Fetch-Dest')
            origin_kind=_origin_class(origin,port)
            if not _origin_allowed(origin,site,mode,dest,port):
                # Distinguish Android opaque origins from true foreign origins
                # without leaking the raw header, query token or CSRF nonce.
                return self._deny('ORIGIN',origin_kind)
            # Same-site is only permitted for a confirmed exact loopback origin.
            if site not in (None,'same-origin','none') and not (site=='same-site' and origin_kind=='exact-loopback'):
                return self._deny('FETCH_SITE')
            if self.headers.get('Content-Type','').split(';',1)[0].strip().lower()!='application/x-www-form-urlencoded':
                return self.headers_safe(415)
            length=self.headers.get('Content-Length','')
            if not length.isdecimal() or not 0<int(length)<=PAGE_LIMIT:
                return self.headers_safe(413)
            try:
                raw=self.rfile.read(int(length)).decode('utf-8','strict')
                args=parse_qs(raw,keep_blank_values=True,strict_parsing=True,max_num_fields=12)
                if set(args).issuperset({'csrf'}) and len(args['csrf'])==1 and hmac.compare_digest(args['csrf'][0],csrf):
                    pass
                else:return self._deny('CSRF')
                route=urlsplit(self.path).path
                if route=='/action/widget-enroll':
                    if set(args)!={'csrf'}:raise ValueError('unexpected widget pairing fields')
                    if coordinator.active()['running']:raise ValueError('worker active; widget setup on HOLD')
                    key=widget_status.enroll(base)
                    page=_layout('Mini Widget', '<section class="panel"><h2>Cheia Mini Widget (o singură afișare)</h2>'
                        '<p class="warn">Copiază cheia în aplicația Android TRINITY Mini Cockpit. Nu o publica, nu trimite capturi cu cheia.</p>'
                        +'<p class="mono">'+escape(key)+'</p><p>Acces: NUMAI STARE / READ-ONLY.</p></section>',token)
                    return self._response(200,page)
                if route=='/action/update-enroll':
                    if set(args)!={'csrf','public_pem','fingerprint','url'} or any(len(x)!=1 for x in args.values()):
                        raise ValueError('invalid one-time publisher setup')
                    if coordinator.active()['running'] or coordinator.active()['maintenance']:
                        raise ValueError('worker busy; publisher setup blocked')
                    updater.enroll_channel(base,args['public_pem'][0].replace('\r\n','\n').encode('ascii'),
                                           args['fingerprint'][0],args['url'][0])
                    return self._go('/updates')
                if route=='/action/update-check':
                    if set(args)!={'csrf'}:raise ValueError('unexpected update form')
                    try:updater.fetch_channel(base)
                    except Exception as exc:
                        raise ValueError('update check HOLD: '+type(exc).__name__) from exc
                    return self._go('/updates')
                if route=='/action/update-cancel':
                    if set(args)!={'csrf','digest'} or len(args['digest'])!=1:
                        raise ValueError('invalid update cancellation')
                    updater.cancel_staged(base,args['digest'][0])
                    return self._go('/updates')
                if route in ('/action/update-approve-restart','/action/update-restart'):
                    if not supervised:raise ValueError('Restart requires the verified TRINITY widget launcher')
                    if route=='/action/update-restart' and set(args)!={'csrf'}:
                        raise ValueError('unexpected update form')
                    if route=='/action/update-approve-restart' and (
                            set(args)!={'csrf','digest'} or len(args['digest'])!=1):
                        raise ValueError('unexpected update approval')
                    with coordinator.guard:
                        if coordinator.running or coordinator.maintenance:
                            raise ValueError('worker busy; restart not permitted')
                        if route=='/action/update-approve-restart':
                            updater.approve(base,args['digest'][0])
                        elif not updater.status(base).get('approved'):
                            raise ValueError('no approved release')
                        coordinator.maintenance=True
                    # Return a useful page before shutting down. No arbitrary shell.
                    page=_layout('Repornire', '<section class="panel"><h2>Repornire controlată</h2>'
                        '<p>TRINITY repornește și verifică actualizarea. Dacă apar '
                        'probleme, activează rollbackul. Reîncarcă Panoul după câteva secunde.</p>'
                        '</section>', token,refresh=True)
                    self._response(200,page)
                    self.server.restart_requested=True
                    threading.Thread(target=self.server.shutdown,daemon=True).start()
                    return
                if route=='/action/plan':
                    created=_create_plan(base,args)
                    return self._go('/review/'+created['id'])
                if route not in ('/action/approve-start','/action/start','/action/revoke'):
                    return self.headers_safe(404)
                if set(args)!={'csrf','id','digest'} or any(len(v)!=1 for v in args.values()):
                    raise ValueError('invalid action contract')
                ident=args['id'][0]
                path=discovery.directory(coordinator.root,ident)
                plan=discovery.validate_plan(load(path/'plan.json'))
                if plan['id']!=ident or not hmac.compare_digest(args['digest'][0],digest(plan)):
                    raise ValueError('plan digest mismatch')
                if route=='/action/revoke':
                    discovery.revoke(coordinator.root,ident)
                elif route=='/action/approve-start':
                    discovery.authorize(coordinator.root,ident)
                    coordinator.dispatch(ident)
                else:
                    coordinator.dispatch(ident)
                return self._go('/review/'+ident)
            except (ValueError,KeyError,TypeError,OverflowError,OSError,UnicodeError) as exc:
                return self._response(409,_layout('HOLD',f'<section class="panel"><h2 class="bad">Acțiune blocată (HOLD)</h2><p>{escape(str(exc))}</p></section>',token))
        def do_PUT(self):return self.headers_safe(405)
        def do_DELETE(self):return self.headers_safe(405)
    return Handler


def serve(base='.',port=8767):
    if type(port) is not int or not 1024<=port<=65535:
        raise ValueError('invalid port')
    base=Path(base).resolve()
    # Stable private session permits an Android home-screen shortcut after first login.
    authfile=base/'.trinity-local-session.json'
    if authfile.exists():
        if authfile.is_symlink() or authfile.stat().st_mode & 0o077:
            raise ValueError('unsafe persistent browser session permissions')
        session=json.loads(authfile.read_bytes())
        if (not isinstance(session,dict) or set(session)!={'token','csrf'}
                or any(type(session[k]) is not str or len(session[k])<40 for k in session)):
            raise ValueError('invalid browser session')
    else:
        session={'token':secrets.token_urlsafe(32),'csrf':secrets.token_urlsafe(32)}
        fd=os.open(authfile,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:
            json.dump(session,f)
            f.flush();os.fsync(f.fileno())
    token=session['token'];csrf=session['csrf']
    coordinator=Coordinator(base)
    supervised = os.environ.get('TRINITY_SUPERVISED')=='1'
    server=ThreadingHTTPServer(('127.0.0.1',port),handler_factory(base,token,csrf,coordinator,port,supervised))
    server.daemon_threads=True
    server.restart_requested=False
    print('TRINITY Mobile Cockpit — numai pe telefon, cu aprobare limitată:',flush=True)
    print(f'http://127.0.0.1:{port}/?token={token}',flush=True)
    print('Păstrează acest terminal deschis; CTRL+C oprește panoul.',flush=True)
    try:
        server.serve_forever(poll_interval=.25)
    except KeyboardInterrupt:pass
    finally:
        server.server_close()
    return 75 if server.restart_requested else 0


def main():
    parser=argparse.ArgumentParser(description='TRINITY Mobile Cockpit: phone-only bounded controls')
    parser.add_argument('--base',default='.')
    parser.add_argument('--port',type=int,default=8767)
    args=parser.parse_args()
    raise SystemExit(serve(args.base,args.port))

if __name__=='__main__':main()
