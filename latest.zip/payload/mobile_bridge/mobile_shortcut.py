"""One-time Termux:Widget launcher creator; never auto-enables Android boot."""
import os
import subprocess
import sys
from pathlib import Path


def install_widget(base,home=None):
    base=Path(base).resolve()
    if not (base/'TRINITY-START.sh').is_file():
        raise ValueError('TRINITY launcher missing')
    home=Path(home) if home is not None else Path.home()
    folder=home/'.shortcuts'
    if folder.is_symlink():raise ValueError('unsafe shortcuts directory')
    folder.mkdir(mode=0o700,exist_ok=True)
    os.chmod(folder,0o700)
    path=folder/'TRINITY'
    if path.exists() or path.is_symlink():
        raise ValueError('TRINITY shortcut already exists; refusing overwrite')
    # quoted cwd: no interpolation and no remote commands.
    import shlex
    code=('#!/data/data/com.termux/files/usr/bin/bash\n'
          'set -euo pipefail\n'
          f'cd {shlex.quote(str(base))}\n'
          'exec python -m mobile_bridge.mobile_shortcut launch\n')
    fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o700)
    with os.fdopen(fd,'w') as f:
        f.write(code);f.flush();os.fsync(f.fileno())
    return {'status':'SHORTCUT_CREATED','path':str(path),
            'next':'Install Termux:Widget from the same source as Termux, then add its widget to the home screen.'}



# The widget and existing server prove common ownership of the local browser
# session without sending browser credentials to an unknown port occupant.
# This is a local same-user check, NOT protection against hostile Termux UID.

def _private_session(base):
    import json
    import stat
    path=Path(base)/'.trinity-local-session.json'
    if path.is_symlink() or not path.is_file():
        raise ValueError('trusted browser session missing or unsafe')
    st=path.stat()
    if not stat.S_ISREG(st.st_mode) or st.st_mode & 0o077:
        raise ValueError('trusted browser session permissions unsafe')
    obj=json.loads(path.read_bytes())
    if (not isinstance(obj,dict) or set(obj)!={'token','csrf'} or
            any(type(obj[k]) is not str or len(obj[k])<40 for k in obj)):
        raise ValueError('invalid trusted browser session')
    return obj


def _probe_instance(base,port=8767,timeout=1.5):
    """Return 'ABSENT' or 'TRUSTED'; raise HOLD for unknown port occupants.

    Read-only loopback challenge using a fresh nonce and a MAC from the private
    session. No redirects, cookies, token, or query bearer are sent to the port.
    """
    import http.client
    import hmac
    import json
    import secrets
    from .cockpit import INSTANCE_ROUTE,INSTANCE_SCHEMA,instance_proof
    nonce=secrets.token_hex(32)
    conn=http.client.HTTPConnection('127.0.0.1',port,timeout=timeout)
    try:
        try:
            conn.request('GET',INSTANCE_ROUTE+'?nonce='+nonce,headers={
                'Host':f'127.0.0.1:{port}', 'Accept':'application/json',
                'Connection':'close'})
            resp=conn.getresponse()
        except ConnectionRefusedError:
            return 'ABSENT'
        if resp.status != 200:
            raise ValueError('cockpit port occupied by an unverified or older server; stop the old server in its original Termux session, then retry (HOLD)')
        if resp.getheader('Content-Length') and int(resp.getheader('Content-Length')) > 2048:
            raise ValueError('oversized instance reply (HOLD)')
        payload=resp.read(2049)
        if len(payload)>2048:
            raise ValueError('oversized instance reply (HOLD)')
        try:
            obj=json.loads(payload)
            if (type(obj) is not dict or set(obj)!={'schema','nonce','proof'} or
                    obj['schema']!=INSTANCE_SCHEMA or obj['nonce']!=nonce or
                    type(obj['proof']) is not str or len(obj['proof'])!=64):
                raise ValueError('unexpected instance reply')
            session=_private_session(base)
            expected=instance_proof(session['token'],session['csrf'],base,port,nonce)
            if not hmac.compare_digest(obj['proof'],expected):
                raise ValueError('incorrect instance proof')
        except (UnicodeError,ValueError,KeyError,TypeError) as exc:
            raise ValueError('cockpit instance identity not verified (HOLD)') from exc
        return 'TRUSTED'
    except (OSError,TimeoutError) as exc:
        raise ValueError('cockpit port unavailable or unresponsive (HOLD)') from exc
    finally:
        conn.close()


def _widget_lock(base):
    import fcntl
    import stat
    path=Path(base)/'.trinity-widget-start.lock'
    flags=os.O_CREAT|os.O_RDWR
    if hasattr(os,'O_NOFOLLOW'): flags |= os.O_NOFOLLOW
    fd=os.open(path,flags,0o600)
    try:
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_mode & 0o077:
            raise ValueError('unsafe widget launch lock')
        fcntl.flock(fd,fcntl.LOCK_EX)
        return fd
    except BaseException:
        os.close(fd)
        raise


def _android_user_id(env=None):
    """Use Termux's numeric Android user profile, never shell interpolation."""
    import re
    env=os.environ if env is None else env
    value=env.get('TERMUX__USER_ID', '0')
    if not isinstance(value,str) or not re.fullmatch(r'(0|[1-9][0-9]{0,5})',value):
        raise ValueError('invalid Android user profile (HOLD)')
    return value


def _launch_chrome(url, timeout=12):
    """Request an explicit Chrome Android activity; never claim foreground success.

    The native activity manager can report that an intent was dispatched but
    Android may still restrict bringing another app to the foreground. Capture
    all output because it can contain the browser bearer token.
    """
    cmd=['am','start','--user',_android_user_id(),'-W',
         '-a','android.intent.action.VIEW','-d',url,
         '-p','com.android.chrome']
    try:
        result=subprocess.run(cmd,stdin=subprocess.DEVNULL,
                              stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              timeout=timeout,check=False)
    except (OSError,subprocess.SubprocessError):
        return False
    # Some Android builds return 0 for an activity-manager error message.
    output=(result.stdout+result.stderr).decode('utf-8','replace').lower()
    if result.returncode or ('error:' in output or 'exception' in output or
                             'unable to resolve intent' in output or
                             'permission denial' in output):
        return False
    return True


def _open_trusted_cockpit(base):
    # Never send a bearer token to an unidentified port listener. The caller
    # must have freshly verified the local challenge (or just started it).
    session=_private_session(base)
    from urllib.parse import urlencode
    url='http://127.0.0.1:8767/?'+urlencode({'token':session['token']})
    if _launch_chrome(url):
        print('TRINITY: Chrome launch requested via Android activity manager; '
              'check phone screen.',flush=True)
        return True
    print('TRINITY: Android did not confirm a Chrome launch. '
          'Open http://127.0.0.1:8767 in Chrome (previous session cookie required). '
          'Do not share the private token.',flush=True)
    return False


def launch_widget(base, port=8767, startup_timeout=45):
    """One-tap start/reuse with strict local identity and singleton startup.

    The lock serializes rapid widget taps during startup, but is released once
    Cockpit is ready. The first launcher then waits for its own bootloader.
    """
    import fcntl
    import time
    base=Path(base).resolve()
    if port != 8767:
        raise ValueError('widget port is pinned to 8767')
    if not (base/'TRINITY-START.sh').is_file():
        raise ValueError('TRINITY launcher missing')
    lockfd=_widget_lock(base)
    child=None
    raced_trusted=False
    try:
        state=_probe_instance(base,port)
        if state=='TRUSTED':
            _open_trusted_cockpit(base)
            print('TRINITY already running; reused verified instance',flush=True)
            return 0
        if state!='ABSENT': raise ValueError('unknown instance probe state')
        cmd=[sys.executable,'-m','mobile_bridge.bootloader',
             '--base',str(base),'--port',str(port)]
        child=subprocess.Popen(cmd,cwd=base,stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL)
        until=time.monotonic()+startup_timeout
        while time.monotonic()<until:
            if child.poll() is not None:
                # A competing trusted starter might have acquired the port.
                if _probe_instance(base,port)=='TRUSTED':
                    raced_trusted=True
                    break
                raise ValueError('TRINITY bootloader exited before ready (HOLD)')
            state=_probe_instance(base,port)
            if state=='TRUSTED':break
            time.sleep(0.2)
        else:
            raise ValueError('TRINITY readiness timeout (HOLD)')
        _open_trusted_cockpit(base)
        if raced_trusted:
            print('TRINITY already running; reused concurrently started instance',flush=True)
        else:
            print('TRINITY Cockpit ready (single-instance)',flush=True)
    except BaseException:
        # Do not kill unknown listeners. Only terminate our child, if any.
        if child is not None and child.poll() is None:
            child.terminate()
            try:child.wait(timeout=5)
            except subprocess.TimeoutExpired:child.kill();child.wait()
        raise
    finally:
        fcntl.flock(lockfd,fcntl.LOCK_UN)
        os.close(lockfd)
    # If our contender lost the port race to a verified instance, it is success.
    if raced_trusted:return 0
    # Keep our managed Cockpit alive in this foreground Widget session.
    try:
        return child.wait()
    except KeyboardInterrupt:
        child.terminate()
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:child.kill();child.wait()
        return 0


def main():
    import json
    command=sys.argv[1] if len(sys.argv)>1 else 'install'
    try:
        if command=='launch':
            sys.exit(launch_widget('.'))
        if command!='install':raise ValueError('unknown shortcut operation')
        print(json.dumps(install_widget('.'),indent=2))
    except (ValueError,OSError) as e:
        print('HOLD:',str(e),file=sys.stderr);sys.exit(2)

if __name__=='__main__':main()
