# TRINITY — actualizări sigure din Cockpit (RC4)

## Utilizare zilnică după configurarea inițială

1. Pornește TRINITY din Termux:Widget. Chrome se deschide automat pe telefonul
   calificat cu RC3. Dacă există deja un Cockpit identificat, acesta este refolosit.
2. În **Actualizări verificate** → **Verifică actualizări semnate**. Nu se
   descarcă nimic fără apăsarea ta. Offline, TRINITY rămâne funcțional.
3. Dacă există release nou: verifică **versiunea**, **secvența**, **amprenta
   manifestului** și **fișierele**. Nu apăsa Aprobare dacă există orice neclaritate.
4. **Aprob exact această actualizare și repornesc**. Cererea este validată prin
   token local, CSRF, origine și blocajul workerului. Nu acceptă comenzi shell.
5. Lansatorul aplică numai fișierele permise după verificarea Ed25519/SHA-256,
   rulează regresia nativă, lansează noul Cockpit, verifică identitatea și
   disponibilitatea, apoi confirmă versiunea. În caz de eșec: **rollback**.
6. Dacă nu dorești update-ul pregătit, apasă **Renunță la această actualizare**,
   disponibil doar înainte de aprobare.

## O SINGURĂ configurare a canalului

Pe ecranul Actualizări, `NO_TRUST_KEY` arată că telefonul NU are încă un editor
semnatar de încredere. Poți configura o dată cheia **PUBLICĂ** Ed25519, amprenta
SHA-256 verificată pe o cale independentă, și un URL HTTPS fix. Nu introduce
niciodată cheia privată aici. O cheie nu se rotește din browser. Detalii pentru
publisher: `docs/TRINITY_SIGNED_CHANNEL_RC4.md`.

Nu avem încă un publisher oficial al utilizatorului, o cheie verificată sau un
server de release activ în acest pachet; așadar actualizările din browser NU
vor fi disponibile până la configurarea lor reală. Nu presupunem că un URL sau
o cheie furnizată de altcineva sunt de încredere.

## Limitări asumate

Canalul semnat din RC4 poate actualiza **numai**:
`mobile_bridge/cockpit.py`, `mobile_bridge/mobile_shortcut.py` și acest ghid.
Nu actualizează engine/autoritatea, bootloader, updaterul sau cheia editorului.
Schimbările acestora necesită alt mecanism de distribuție verificat.

Încă necalificat pe telefon: RC4, reboot în timpul instalării, recuperare după
oprirea Android, execuție îndelungată cu ecranul stins și automatizare la boot.
Semnătura nu protejează împotriva unui proces ostil cu acces la fișierele private
ale Termux. NU activa un server public pe `0.0.0.0`.
